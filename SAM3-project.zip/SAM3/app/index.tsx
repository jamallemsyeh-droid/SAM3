import { useState } from 'react';
import { View, Text, ScrollView, Pressable, Switch, StyleSheet } from 'react-native';
import { AudioControls } from '@/components/AudioControls';
import { alertTypes, AlertId } from '@/config/alerts';

export default function HomeScreen() {
  const [active, setActive] = useState(false);
  const [enabled, setEnabled] = useState<AlertId[]>(alertTypes.map(x => x.id));
  const [captions, setCaptions] = useState(true);
  const [vibration, setVibration] = useState(true);
  const [noiseFilter, setNoiseFilter] = useState(true);

  const toggleAlert = (id: AlertId) => setEnabled(old =>
    old.includes(id) ? old.filter(x => x !== id) : [...old, id]
  );

  return <ScrollView style={s.page} contentContainerStyle={s.content}>
    <View style={s.hero}>
      <Text style={s.brand}>◉ سَمْع SAM3</Text>
      <Text style={s.heading}>اسمع العالم بوضوح أكبر</Text>
      <Text style={s.sub}>مساعد سمعي وإمكانية وصول</Text>
    </View>
    <AudioControls active={active} onToggle={() => setActive(v => !v)} />
    <Text style={s.section}>إعدادات المساعدة</Text>
    <Setting title="تحويل الكلام إلى نص" value={captions} onChange={setCaptions}/>
    <Setting title="تقليل الضوضاء (عند دعم المعالجة)" value={noiseFilter} onChange={setNoiseFilter}/>
    <Setting title="الاهتزاز عند التنبيه" value={vibration} onChange={setVibration}/>
    <Text style={s.section}>الأصوات التي تريد اكتشافها</Text>
    <Text style={s.note}>تفعيل الفئات هنا يحفظ تفضيلات الواجهة فقط؛ يلزم ربط نموذج تصنيف صوتي فعلي قبل اكتشافها.</Text>
    {alertTypes.map(item => <Setting key={item.id} title={item.label} value={enabled.includes(item.id)} onChange={() => toggleAlert(item.id)} />)}
    <Text style={s.footer}>تنبيه: لا تعتمد على التطبيق وحده لاكتشاف الحريق أو مخاطر المرور. استخدم أجهزة الإنذار المعتمدة.</Text>
  </ScrollView>;
}
function Setting({title,value,onChange}:{title:string;value:boolean;onChange:(v:boolean)=>void}) {
  return <View style={s.setting}><Text style={s.settingText}>{title}</Text><Switch value={value} onValueChange={onChange} trackColor={{true:'#176B87'}} /></View>;
}
const s=StyleSheet.create({
 page:{flex:1,backgroundColor:'#F4F8FA'},content:{padding:18,paddingBottom:40,gap:14},
 hero:{backgroundColor:'#105A76',padding:22,borderRadius:22,marginBottom:4},
 brand:{color:'#fff',fontSize:25,fontWeight:'800',textAlign:'right'},
 heading:{color:'#fff',fontSize:22,fontWeight:'700',textAlign:'right',marginTop:18},
 sub:{color:'#D8EDF3',textAlign:'right',marginTop:5},
 section:{fontSize:18,fontWeight:'800',color:'#123B4B',textAlign:'right',marginTop:10},
 note:{color:'#617681',textAlign:'right',lineHeight:21},
 setting:{backgroundColor:'#fff',borderRadius:14,paddingHorizontal:15,paddingVertical:13,flexDirection:'row-reverse',alignItems:'center',justifyContent:'space-between'},
 settingText:{fontSize:15,color:'#173744',flex:1,textAlign:'right',marginLeft:12},
 footer:{color:'#8A4B16',backgroundColor:'#FFF3E4',padding:14,borderRadius:12,textAlign:'right',lineHeight:22,marginTop:8}
});
