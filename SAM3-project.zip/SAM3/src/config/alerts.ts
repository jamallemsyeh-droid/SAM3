export const alertTypes = [
 {id:'doorbell',label:'جرس الباب'},
 {id:'vehicle_horn',label:'أبواق السيارات'},
 {id:'fire_alarm',label:'إنذار الحريق والدخان'},
 {id:'knocking',label:'طرق الباب'},
 {id:'alarm_clock',label:'المنبهات وأجهزة الإنذار'},
 {id:'baby_cry',label:'بكاء الأطفال'},
 {id:'emergency_siren',label:'صفارات الطوارئ'},
 {id:'calling_voice',label:'شخص يناديك'}
] as const;
export type AlertId = typeof alertTypes[number]['id'];
