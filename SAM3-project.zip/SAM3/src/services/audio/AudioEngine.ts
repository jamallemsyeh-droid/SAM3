/**
 * SAM3 audio-engine boundary.
 *
 * IMPORTANT: This is intentionally a stub. A safe, low-latency live monitor needs
 * native audio capture + simultaneous output/routing and platform-specific testing.
 * Do not replace this with a record-then-play loop: that introduces delay and may
 * create feedback. Implement with a vetted native audio pipeline and headphones-only
 * monitoring, conservative gain limits, clipping detection and an immediate stop.
 */
export interface AudioEngine {
  requestPermission(): Promise<boolean>;
  start(): Promise<void>;
  stop(): Promise<void>;
}
export class UnimplementedAudioEngine implements AudioEngine {
  async requestPermission() { return false; }
  async start() { throw new Error('Live audio engine is not implemented yet.'); }
  async stop() { /* no-op */ }
}
