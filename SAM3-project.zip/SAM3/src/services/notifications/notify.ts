import * as Notifications from 'expo-notifications';
import * as Haptics from 'expo-haptics';

export async function requestNotificationPermission() {
  const result = await Notifications.requestPermissionsAsync();
  return result.granted;
}
export async function notifySound(label: string, vibrate: boolean) {
  await Notifications.scheduleNotificationAsync({
    content: { title: 'سمع اكتشف صوتاً', body: label, sound: true },
    trigger: null
  });
  if (vibrate) await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
}
