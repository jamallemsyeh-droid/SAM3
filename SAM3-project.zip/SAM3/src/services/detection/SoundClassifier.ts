/**
 * Sound-event detection contract.
 * A real implementation must use a validated audio-event model and evaluate
 * false positives/negatives in varied homes and outdoor environments.
 * Fire/traffic alerts must never be presented as guaranteed safety detection.
 */
export type SoundEvent =
  | 'doorbell' | 'vehicle_horn' | 'fire_alarm' | 'knocking'
  | 'alarm_clock' | 'baby_cry' | 'emergency_siren' | 'calling_voice';
export interface SoundClassifier {
  load(): Promise<void>;
  classify(audioFrame: Float32Array): Promise<{event: SoundEvent; confidence: number} | null>;
}
