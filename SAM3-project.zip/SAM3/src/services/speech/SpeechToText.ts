/**
 * Speech-to-text adapter contract.
 * Connect a platform speech recognizer or a privacy-reviewed on-device model.
 * Request microphone/speech permissions and show clear recording indicators.
 */
export type TranscriptListener = (text: string, isFinal: boolean) => void;
export interface SpeechToText {
  start(locale: string, onResult: TranscriptListener): Promise<void>;
  stop(): Promise<void>;
}
