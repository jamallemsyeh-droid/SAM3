import { View, Text, Pressable, StyleSheet } from 'react-native';
export function AudioControls({active,onToggle}:{active:boolean;onToggle:()=>void}) {
 return <View style={s.card}>
   <Text style={s.title}>الاستماع المباشر</Text>
   <Text style={s.status}>{active?'تم تفعيل وضع الواجهة':'جاهز للبدء'}</Text>
   <Pressable accessibilityRole="button" onPress={onToggle} style={[s.button,active&&s.stop]}>
     <Text style={s.buttonText}>{active?'إيقاف':'ابدأ الاستماع'}</Text>
   </Pressable>
   <Text style={s.hint}>زر تجريبي حالياً. لم يتم توصيل مسار صوت حي بعد.</Text>
 </View>;
}
const s=StyleSheet.create({card:{backgroundColor:'#fff',padding:18,borderRadius:20,gap:10},title:{fontSize:18,fontWeight:'800',textAlign:'right',color:'#123B4B'},status:{textAlign:'right',color:'#607783'},button:{backgroundColor:'#167B56',padding:15,borderRadius:13},stop:{backgroundColor:'#A33D3D'},buttonText:{color:'#fff',fontWeight:'800',textAlign:'center',fontSize:16},hint:{fontSize:12,color:'#75858D',textAlign:'right'}});
